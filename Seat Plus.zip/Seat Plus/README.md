This pack was created by
>= Xbox - CTabdul15
>= Youtube - CTabdul15
>= Discord - ctabdul15
>= Discord Server - https://discord.gg/5kwkGnZagR

----------------------------------------------------------------------------------------------------------------------------------------------------------------

To open the addon settings write "/function sitOnBlocks/settings" in the chat and a menu will appear

----------------------------------------------------------------------------------------------------------------------------------------------------------------


If you wish to edit this pack, contact me on discord ctabdul15 why you wish to edit the pack and what you plan to achieve with editing the pack.
